"use strict";(()=>{var e={};e.id=9118,e.ids=[9118],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},50852:e=>{e.exports=require("async_hooks")},32081:e=>{e.exports=require("child_process")},6113:e=>{e.exports=require("crypto")},82361:e=>{e.exports=require("events")},57147:e=>{e.exports=require("fs")},73292:e=>{e.exports=require("fs/promises")},22037:e=>{e.exports=require("os")},71017:e=>{e.exports=require("path")},76224:e=>{e.exports=require("tty")},73837:e=>{e.exports=require("util")},94495:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>w,patchFetch:()=>k,requestAsyncStorage:()=>f,routeModule:()=>m,serverHooks:()=>b,staticGenerationAsyncStorage:()=>y});var n={};r.r(n),r.d(n,{POST:()=>h});var o=r(49303),s=r(88716),a=r(60670),i=r(87070),l=r(47348);let p=process.env.EMAIL_FROM||"Sorokid <onboarding@resend.dev>";async function u({from:e,to:t,subject:r,html:n,text:o}){let s=process.env.RESEND_API_KEY;if(!s)return{success:!1,error:"Email service not configured"};try{let a=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${s}`,"Content-Type":"application/json"},body:JSON.stringify({from:e||p,to:Array.isArray(t)?t:[t],subject:r,html:n,text:o})}),i=await a.json();if(!a.ok)return{success:!1,error:i.message||"Failed to send email"};return{success:!0,id:i.id}}catch(e){return{success:!1,error:e.message}}}async function d(e,t,r=""){let n=r||"bạn",o=`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Đặt lại mật khẩu - SoroKid</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #EEF2FF;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #EEF2FF; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 520px; background-color: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(99, 102, 241, 0.15);">
          
          <!-- Header với Logo Text -->
          <tr>
            <td style="background: linear-gradient(135deg, #4F7FFF 0%, #8B5CF6 50%, #EC4899 100%); padding: 36px 30px; text-align: center;">
              <!-- Logo Text -->
              <table cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                <tr>
                  <td style="background-color: #ffffff; border-radius: 16px; padding: 14px 28px; box-shadow: 0 4px 16px rgba(0,0,0,0.12);">
                    <span style="font-size: 32px; font-weight: 800; color: #4F7FFF;">Soro</span><span style="font-size: 32px; font-weight: 800; color: #EC4899;">Kid</span>
                  </td>
                </tr>
              </table>
              <p style="color: rgba(255,255,255,0.95); margin: 16px 0 0 0; font-size: 15px; font-weight: 500;">
                🧒 Học to\xe1n tư duy c\xf9ng b\xe0n t\xednh Soroban
              </p>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px 36px;">
              <!-- Icon -->
              <div style="text-align: center; margin-bottom: 24px;">
                <span style="display: inline-block; width: 64px; height: 64px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 50%; line-height: 64px; font-size: 32px; box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);">🔐</span>
              </div>
              
              <h2 style="color: #1F2937; margin: 0 0 16px 0; font-size: 24px; font-weight: 700; text-align: center;">
                Xin ch\xe0o ${n}! 👋
              </h2>
              
              <p style="color: #4B5563; font-size: 16px; line-height: 1.7; margin: 0 0 16px 0; text-align: center;">
                Ch\xfang t\xf4i nhận được y\xeau cầu đặt lại mật khẩu cho t\xe0i khoản <strong style="color: #6366F1;">Sorokid</strong> của bạn.
              </p>
              
              <p style="color: #4B5563; font-size: 16px; line-height: 1.7; margin: 0 0 28px 0; text-align: center;">
                Nhấn v\xe0o n\xfat b\xean dưới để tạo mật khẩu mới:
              </p>
              
              <!-- Button -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="${t}" 
                       style="display: inline-block; background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%); 
                              color: #ffffff; text-decoration: none; padding: 18px 48px; border-radius: 50px; 
                              font-size: 16px; font-weight: 700; letter-spacing: 0.3px;
                              box-shadow: 0 8px 24px rgba(99, 102, 241, 0.35);">
                      🔑 Đặt lại mật khẩu
                    </a>
                  </td>
                </tr>
              </table>
              
              <!-- Warning box -->
              <div style="margin-top: 28px; padding: 16px 20px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 12px; border-left: 4px solid #F59E0B;">
                <p style="color: #92400E; font-size: 14px; line-height: 1.5; margin: 0;">
                  ⏰ Link n\xe0y sẽ hết hạn sau <strong>1 giờ</strong>
                </p>
              </div>
              
              <p style="color: #9CA3AF; font-size: 14px; line-height: 1.6; margin: 20px 0 0 0; text-align: center;">
                Nếu bạn kh\xf4ng y\xeau cầu đặt lại mật khẩu, vui l\xf2ng bỏ qua email n\xe0y. T\xe0i khoản của bạn vẫn an to\xe0n.
              </p>
              
              <!-- Fallback link -->
              <div style="margin-top: 28px; padding: 16px 20px; background-color: #F3F4F6; border-radius: 12px;">
                <p style="color: #6B7280; font-size: 13px; margin: 0 0 8px 0;">
                  📎 Nếu n\xfat kh\xf4ng hoạt động, copy link sau:
                </p>
                <p style="color: #6366F1; font-size: 12px; margin: 0; word-break: break-all; font-family: monospace;">
                  ${t}
                </p>
              </div>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%); padding: 28px 30px; text-align: center; border-top: 1px solid #E5E7EB;">
              <!-- Social/Brand -->
              <p style="font-size: 14px; font-weight: 600; margin: 0 0 8px 0;">
                🧮 <span style="color: #4F7FFF;">Soro</span><span style="color: #EC4899;">Kid</span> <span style="color: #6B7280;">- Học to\xe1n tư duy c\xf9ng b\xe0n t\xednh Soroban</span>
              </p>
              <p style="color: #9CA3AF; font-size: 12px; margin: 0 0 12px 0;">
                R\xe8n luyện tr\xed n\xe3o, ph\xe1t triển tư duy to\xe1n học cho b\xe9
              </p>
              <p style="color: #D1D5DB; font-size: 11px; margin: 0;">
                \xa9 ${new Date().getFullYear()} <span style="color: #4F7FFF;">Soro</span><span style="color: #EC4899;">Kid</span>. Email tự động - vui l\xf2ng kh\xf4ng trả lời.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `,s=`
Xin ch\xe0o ${n}!

Ch\xfang t\xf4i nhận được y\xeau cầu đặt lại mật khẩu cho t\xe0i khoản Sorokid của bạn.

Nhấn v\xe0o link sau để tạo mật khẩu mới:
${t}

Link n\xe0y sẽ hết hạn sau 1 giờ.

Nếu bạn kh\xf4ng y\xeau cầu đặt lại mật khẩu, vui l\xf2ng bỏ qua email n\xe0y.

---
SoroKid - Học to\xe1n tư duy c\xf9ng b\xe0n t\xednh Soroban
  `.trim(),a=await u({to:e,subject:"\uD83D\uDD10 Đặt lại mật khẩu Sorokid",html:o,text:s});return a.success,a}var c=r(6113),x=r.n(c);let g=new Map;async function h(e){try{if(!process.env.RESEND_API_KEY)return i.NextResponse.json({error:"Dịch vụ email chưa được cấu h\xecnh. Vui l\xf2ng li\xean hệ admin."},{status:503});let{email:t}=await e.json();if(!t||"string"!=typeof t)return i.NextResponse.json({error:"Vui l\xf2ng nhập email"},{status:400});let r=t.toLowerCase().trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r))return i.NextResponse.json({error:"Email kh\xf4ng hợp lệ"},{status:400});if(!function(e){let t=Date.now(),r=e.toLowerCase(),n=g.get(r);return!n||t-n.firstRequest>9e5?(g.set(r,{count:1,firstRequest:t}),!0):!(n.count>=3)&&(n.count++,!0)}(r))return i.NextResponse.json({error:"Bạn đ\xe3 gửi qu\xe1 nhiều y\xeau cầu. Vui l\xf2ng thử lại sau 15 ph\xfat."},{status:429});let n=await l._B.user.findUnique({where:{email:r},select:{id:!0,email:!0,name:!0}});if(!n)return i.NextResponse.json({success:!0,message:"Nếu email tồn tại trong hệ thống, bạn sẽ nhận được link đặt lại mật khẩu."});let o=x().randomBytes(32).toString("hex"),s=new Date(Date.now()+36e5);await l._B.passwordReset.updateMany({where:{email:r,used:!1,expiresAt:{gt:new Date}},data:{used:!0}}),await l._B.passwordReset.create({data:{email:r,token:o,expiresAt:s}});let a=process.env.NEXTAUTH_URL||process.env.NEXT_PUBLIC_APP_URL||"http://localhost:3000",p=`${a}/reset-password?token=${o}`;if(!(await d(r,p,n.name)).success)return i.NextResponse.json({error:"Kh\xf4ng thể gửi email. Vui l\xf2ng thử lại sau."},{status:500});return i.NextResponse.json({success:!0,message:"Nếu email tồn tại trong hệ thống, bạn sẽ nhận được link đặt lại mật khẩu."})}catch(e){return i.NextResponse.json({error:"Đ\xe3 xảy ra lỗi. Vui l\xf2ng thử lại sau."},{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/auth/forgot-password/route",pathname:"/api/auth/forgot-password",filename:"route",bundlePath:"app/api/auth/forgot-password/route"},resolvedPagePath:"F:\\Recovered_18_49_43\\New Volume(E)\\sorokids\\sorokid_github\\app\\api\\auth\\forgot-password\\route.js",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:f,staticGenerationAsyncStorage:y,serverHooks:b}=m,w="/api/auth/forgot-password/route";function k(){return(0,a.patchFetch)({serverHooks:b,staticGenerationAsyncStorage:y})}},49397:(e,t,r)=>{r.d(t,{FD:()=>i,Hz:()=>l,aU:()=>d,ej:()=>p,oo:()=>a,s0:()=>g,zj:()=>x});let n=process.env.RUNTIME_ENV||"shared",o="shared"===n,s="vps"===n,a={connectionLimit:o?5:20,poolTimeout:o?20:30,connectTimeout:15,socketTimeout:o?45:60,queryTimeout:o?25e3:6e4,logLevel:["error"],retry:{attempts:o?1:3,delay:1e3}},i={login:{maxFailedAttempts:o?5:10,lockDurations:o?[3e4,6e4,3e5,9e5,36e5]:[6e4,3e5,9e5,36e5,864e5],resetWindow:18e5,rateLimit:{windowMs:6e4,maxRequests:o?10:30},minResponseDelay:o?500:200,maxEntries:o?3e3:1e4},session:{secret:process.env.NEXTAUTH_SECRET||process.env.JWT_SECRET,maxAge:86400,updateAge:3600}},l={requests:{maxConcurrent:o?25:200,maxQueueSize:o?80:500,queueTimeout:o?8e3:3e4,priorityAPIs:["/api/auth","/api/lessons","/api/progress","/api/exercises"],heavyAPIs:["/api/dashboard/stats","/api/leaderboard","/api/admin"],maxHeavyConcurrent:o?5:20},rateLimit:{strict:{windowMs:6e4,maxRequests:o?30:60},moderate:{windowMs:6e4,maxRequests:o?100:200},normal:{windowMs:6e4,maxRequests:o?200:500},relaxed:{windowMs:6e4,maxRequests:o?500:1e3},maxEntries:o?1e3:5e3,cleanupAge:3e5},timeouts:{default:o?15e3:3e4,heavy:o?12e3:25e3,normal:o?1e4:2e4,light:o?6e3:15e3,background:o?2e3:5e3},circuitBreaker:{errorThreshold:o?10:15,successThreshold:o?2:3,timeout:o?3e4:2e4},polling:{paymentInterval:o?1e4:5e3,maxPolls:o?90:180,autoStopTimeout:o?9e5:18e5}},p={maxSize:o?400:2e3,defaultTTL:o?9e4:6e4,cleanupInterval:12e4,ttl:{short:o?15e3:1e4,medium:o?45e3:3e4,long:o?12e4:9e4,extended:3e5,dashboard:o?45e3:3e4,lessons:o?3e5:18e4,trialSettings:o?6e5:3e5},staleWhileRevalidate:{enabled:o,maxStaleAge:o?18e4:0}},u={ssr:{enabled:s,revalidate:!o&&60},prefetch:{enabled:s,onHoverOnly:o},navigation:{prefetchLinks:s},images:{blur:s,quality:o?75:85}},d={level:o?"error":"warn",console:s,requests:s,slowQueryThreshold:o?5e3:1e4},c={maxProcesses:o?1e3:5e3,memoryWarningThreshold:o?512:2048,maxMapEntries:o?5e3:2e4,maxPendingPromises:o?50:200};function x(){return n}function g(){return{environment:n,isShared:o,isVPS:s,isDev:!1,database:a,auth:i,api:l,cache:p,rendering:u,logging:d,system:c}}},47348:(e,t,r)=>{r.d(t,{ZP:()=>a,_B:()=>s});var n=r(59885),o=r(49397);let s=globalThis.prisma??function(){let e=new n.PrismaClient({log:o.oo.logLevel,datasources:{db:{url:function(){let e=process.env.DATABASE_URL||"";if(!e)return e;try{let t=new URL(e);return t.searchParams.set("connection_limit",String(o.oo.connectionLimit)),t.searchParams.set("pool_timeout",String(o.oo.poolTimeout)),t.searchParams.set("connect_timeout",String(o.oo.connectTimeout)),t.searchParams.set("socket_timeout",String(o.oo.socketTimeout)),t.toString()}catch(t){return e}}()}},errorFormat:"minimal"});return e.$use((o.aU?.slowQueryThreshold,async(e,t)=>{Date.now();let r=await t(e);return Date.now(),r})),e}();if("undefined"!=typeof process){let e=!1,t=async t=>{if(!e){e=!0;try{await Promise.race([s.$disconnect(),new Promise((e,t)=>setTimeout(()=>t(Error("Disconnect timeout")),5e3))])}catch(e){}}};process.on("beforeExit",()=>t("beforeExit")),process.on("SIGINT",()=>t("SIGINT")),process.on("SIGTERM",()=>t("SIGTERM"))}let a=s}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[8948,9476,7070],()=>r(94495));module.exports=n})();